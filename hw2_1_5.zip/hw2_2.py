num = int(input("Количество элементов: "))
n = 0
lst1 = []
while n < num:
    el = input("Введите элемент списка: ")
    lst1.append(el)
    n = n + 1
print(lst1)
n = 0
while (n + 1) < num:
    lst1[n], lst1[n+1] = lst1[n+1], lst1[n]
    n = n + 2
print(lst1)
