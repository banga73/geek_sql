lst1 = ['sp', 1, ['sok']]
print(type(lst1))
n = 0
while n < len(lst1):
    print(type(lst1[n]))
    n = n + 1
