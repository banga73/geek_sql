numbers = [10, 5, 5, 5, 3, 2, 2, 1]
num = int(input("Введите новый элемент: "))
if num in numbers:
    num_ind = numbers.index(num)
    num_count = numbers.count(num)
    numbers.insert(num_ind + num_count, num)
else:
    for el in numbers:
        if num > el:
            numbers.insert(numbers.index(el), num)
            break
if num not in numbers:
    numbers.append(num)
print(numbers)
