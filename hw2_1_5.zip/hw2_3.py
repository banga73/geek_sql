month = int(input("Введите номер месяца: "))
if month < 1 or month > 12:
    print("Вы ввели некорректный номер месяца")
elif month < 3 or month > 11:
    print("Зима")
elif month < 6:
    print("Весна")
elif month < 9:
    print("Лето")
else:
    print("Осень")
months = {1: "Зима", 2: "Зима", 3: "Весна", 4: "Весна", 5: "Весна", 6: "Лето", 7: "Лето", 8: "Лето", 9: "Осень",
          10: "Осень", 11: "Осень", 12: "Зима"}
print(months.get(month))
months_list = ["Зима", "Зима", "Весна", "Весна", "Весна", "Лето", "Лето", "Лето", "Осень", "Осень", "Осень", "Зима"]
print(months_list[month - 1])
