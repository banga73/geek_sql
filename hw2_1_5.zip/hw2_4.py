words = input("Введите текст: ").split()
for word in words:
    print(words.index(word) + 1, word[:10])
