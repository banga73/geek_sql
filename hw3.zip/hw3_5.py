def sum_word():
    s = 0
    while True:
        word_numb = input("Введите число, для завершения работы нажмите q: ").split()
        for numb in word_numb:
            if numb == 'q':
                return s
            else:
                try:
                    s = s + int(numb)
                except ValueError:
                    print('чтобы выйти из программы, нажимите q или введите число')
    return s


print(sum_word())
