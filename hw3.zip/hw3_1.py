def my_f(s1, s2):
    if s2 != 0:
        return s1 / s2
    else:
        return "Деление на 0"


print(my_f(int(input("Введите число: ")), int(input("Введите число: "))))
