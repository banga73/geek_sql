def mult(x, y):
    n = -1
    a = 1 / x
    while n > y:
        a = a / x
        n = n - 1
    return a


print(mult(float(input("Введите действительное число: ")), int(input("Введите целое отрицательное число: "))))
