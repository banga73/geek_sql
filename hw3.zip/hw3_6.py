def int_func(word):
    f = 0
    for char in word:
        if ord(char) < 97 or ord(char) > 122:
            f += 1
    return word.title() if f == 0 else False


print(int_func(input("Введите слово в нижнем регистре: ")))

words_lower = input("Введите слова в нижнем регистре, разделенные пробелами: ").split()
for w in words_lower:
    print(int_func(w))
