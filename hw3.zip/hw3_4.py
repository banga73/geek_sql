def mult(x, y):
    return x ** y


print(mult(float(input("Введите действительное число: ")), int(input("Введите целое отрицательное число: "))))
