def data_per(name, surname, year, town, email, tel):
    return name + ' ' + surname + ' ' + year + ' ' + town + ' ' + email + ' ' + tel


print(data_per(surname=str(input("Введите фамилию: ")), name=str(input("Введите имя: ")),
               email=str(input("Введите email: ")), tel=str(input("Введите телефон: ")),
               town=str(input("Введите город: ")), year=str(input("Введите год рождения: "))))
