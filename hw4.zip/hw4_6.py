from itertools import count

num = int(input("Введите целое число, меньше 100: "))
if num >= 100:
    print("Число должно быть меньше 100")
for n in count(num):
    if n > 100:
        break
    else:
        print(n)
