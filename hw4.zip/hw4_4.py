from random import randint

my_list = [randint(0, 100) for i in range(30)]
# my_list = [2, 2, 2, 7, 23, 1, 44, 44, 3, 2, 10, 7, 4, 11]
new_list = [n for n in my_list if my_list.count(n) == 1]
print(my_list)
print(new_list)
