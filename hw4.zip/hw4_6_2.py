from itertools import cycle

my_list = ["Настя", "Лёня", "Андрюша"]
сl = 0
for n in cycle(my_list):
    if сl > 10:
        break
    print(n)
    сl += 1
