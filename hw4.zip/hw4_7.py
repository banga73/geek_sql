def fact():
    num = int(input("Введите целое число: "))
    res = 1
    for el in range(1, num + 1):
        res = res * el
        yield res


factor = fact()
for el in factor:
    print(el)
