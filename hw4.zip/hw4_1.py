from sys import argv

name, hours, money, premia = argv
vyplata = int(hours) * int(money) + int(premia)
print("Вам положена выплата: ", vyplata)
